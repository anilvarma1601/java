package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.College;

public interface CollegeService {

	College saveCollege(College college);

	List<College> fetchcollegeList();

	College fetchCollegeById(Long collegeId);

	void deleteCollegeById(Long collegeId);

	College updateCollege(Long collegeId, College college);

}
